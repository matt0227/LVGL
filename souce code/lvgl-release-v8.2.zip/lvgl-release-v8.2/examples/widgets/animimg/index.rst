
Simple Animation Image 
""""""""""""""""

.. lv_example:: widgets/animimg/lv_example_animimg_1
  :language: c
  :description: A simple example to demonstrate the use of an animation image.
